//
//  ViewController.h
//  OC&JS
//
//  Created by wujianqiang on 16/2/24.
//  Copyright © 2016年 wujianqiang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <JavaScriptCore/JavaScriptCore.h>

@protocol JSObjecDelegate <JSExport>

- (void)touchMe:(NSDictionary *)paramater;

@end

@interface ViewController : UIViewController


@end

