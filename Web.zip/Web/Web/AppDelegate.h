//
//  AppDelegate.h
//  Web
//
//  Created by xiaozhou on 16/1/14.
//  Copyright © 2016年 xiaozhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

