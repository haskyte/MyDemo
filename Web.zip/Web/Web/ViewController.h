//
//  ViewController.h
//  Web
//
//  Created by xiaozhou on 16/1/14.
//  Copyright © 2016年 xiaozhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIWebViewDelegate>

@property (weak, nonatomic) IBOutlet UIWebView *webView;

// 两个参数
-(void)getParam1:(NSString*)str1 withParam2:(NSString*)str2;

@end

