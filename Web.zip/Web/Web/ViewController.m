//
//  ViewController.m
//  Web
//
//  Created by xiaozhou on 16/1/14.
//  Copyright © 2016年 xiaozhou. All rights reserved.
//

#import "ViewController.h"
#import "NextViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _webView.delegate = self;
    _webView.backgroundColor = [UIColor clearColor];
    _webView.scalesPageToFit =YES;
    NSString *basePath = [[NSBundle mainBundle]bundlePath];
//    NSString * fileth = [[NSBundle mainBundle]pathForResource:@"jsIOS" ofType:@"html"];
    NSString *helpHtmlPath = [basePath stringByAppendingPathComponent:@"jsIOS.html"];
    NSURL *url = [NSURL fileURLWithPath:helpHtmlPath];
    NSURLRequest *request=[NSURLRequest requestWithURL:url];
    [_webView loadRequest:request];
}
//html页面的js动作触发时运行
- (BOOL)webView:(UIWebView*)webView shouldStartLoadWithRequest:(NSURLRequest*)request navigationType:(UIWebViewNavigationType)navigationType
{
    //获取请求的绝对路径.
    NSString *urlString = [[request URL] absoluteString];
    urlString = [urlString stringByRemovingPercentEncoding];
    NSLog(@"urlString=%@",urlString);
    //提交请求时候分割参数的分隔符
    NSArray *urlComps = [urlString componentsSeparatedByString:@":@@"];
    if([urlComps count] && [[urlComps objectAtIndex:0] isEqualToString:@"objc"]){
        NSArray *arrFucnameAndParameter = [(NSString*)[urlComps objectAtIndex:1] componentsSeparatedByString:@":/"];
        NSString *funcStr = [arrFucnameAndParameter objectAtIndex:0];
        if (1 == [arrFucnameAndParameter count]){
            // 没有参数
            if([funcStr isEqualToString:@"doFunc1"]){
                /*调用本地函数1*/
                NSLog(@"doFunc1");
            }
        }
        else{
            //有参数的
            if([funcStr isEqualToString:@"getParam1:withParam2:"]){
                [self getParam1:[arrFucnameAndParameter objectAtIndex:1] withParam2:[arrFucnameAndParameter objectAtIndex:2]];
                NextViewController * vc = [[NextViewController alloc]init];
                [self presentViewController:vc animated:YES completion:nil];
            }
        }
        return NO;
    }
    return TRUE;
}
-(void)getParam1:(NSString*)str1 withParam2:(NSString*)str2
{
    NSLog(@"收到html传过来的参数：str1=%@,str2=%@",str1,str2);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
